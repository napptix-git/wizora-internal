const { resolve } = require("path");
const fs = require("fs");
const path = require("path");

module.exports = {
  base: "./", // Ensures relative paths work (e.g., ./assets/...)

  publicDir: "public", // Copies /public contents as-is (optional)

  build: {
    outDir: "build",       // Output directory
    assetsDir: "assets",   // All assets go into /build/assets

    rollupOptions: {
      input: {
        main: resolve(__dirname, "index.html"), // Entry HTML
      },
      output: {
        entryFileNames: "script.js",               // Output JS name
        assetFileNames: "assets/[name][extname]",  // Clean asset naming
      },
    },
  },

  plugins: [
    {
      name: "move-css-root",
      closeBundle: () => {
        const buildDir = path.resolve(__dirname, "build");
        const cssInAssets = path.join(buildDir, "assets/index.css");
        const cssInRoot = path.join(buildDir, "style.css");

        // ✅ Move CSS from /assets to root
        if (fs.existsSync(cssInAssets)) {
          fs.renameSync(cssInAssets, cssInRoot);
          console.log("✅ Moved index.css → style.css");
        } else {
          console.warn("⚠️ index.css not found in assets/");
        }

        // ✅ Update <link href="..."> in index.html
        const htmlPath = path.join(buildDir, "index.html");
        if (fs.existsSync(htmlPath)) {
          let html = fs.readFileSync(htmlPath, "utf8");
          html = html.replace(/assets\/index\.css/, "style.css");
          fs.writeFileSync(htmlPath, html);
          console.log("✅ Updated <link> to style.css in index.html");
        }
      },
    },
  ],
};
